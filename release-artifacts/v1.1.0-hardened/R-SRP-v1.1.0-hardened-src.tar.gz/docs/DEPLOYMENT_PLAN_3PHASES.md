# 📋 Plan de Déploiement en 3 Phases

## Registre National des Comptes Bancaires - Architecture Zero-Trust

---

## Vue d'Ensemble du Déploiement

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PLANNING GLOBAL DE DÉPLOIEMENT                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  PHASE 1          PHASE 2              PHASE 3                             │
│  ──────────       ──────────           ──────────                          │
│  6 mois           6 mois               6 mois                              │
│  ──────────       ──────────           ──────────                          │
│  FONDATIONS        RENFORCEMENT         PERFECTION                         │
│                   SÉCURITÉ             AUTO-DÉFENSE                         │
│                                                                             │
│  ════════════════════════════════════════════════════════════════════════  │
│                                                                             │
│  Phase 1:        Phase 2:           Phase 3:                              │
│  ┌──────────┐    ┌──────────┐       ┌──────────┐                          │
│  │ Identity │    │ PAM      │       │ IA       │                          │
│  │ Provider │    │ Complete │       │ Detection│                          │
│  └────┬─────┘    └────┬─────┘       └────┬─────┘                          │
│       │                │                   │                                │
│       ▼                ▼                   ▼                                │
│  ┌──────────┐    ┌──────────┐       ┌──────────┐                          │
│  │ API      │    │ Micro-   │       │ Automated│                          │
│  │ Gateway  │    │ Segments │       │ Response │                          │
│  └────┬─────┘    └────┬─────┘       └────┬─────┘                          │
│       │                │                   │                                │
│       ▼                ▼                   ▼                                │
│  ┌──────────┐    ┌──────────┐       ┌──────────┐                          │
│  │ Logging  │    │ CRUE     │       │ Advanced │                          │
│  │ Immutab. │    │ Engine   │       │ Proof    │                          │
│  └──────────┘    └──────────┘       └──────────┘                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Phase 1: Fondations (Mois 1-6)

### 1.1 Objectifs Phase 1

| Objectif | Description | Livrable |
|----------|-------------|----------|
| **Sécurisation accès** | Mise en place MFA obligatoire | IdP avec FIDO2 |
| **Point d'entrée unique** | API Gateway centralisée | Kong/Apigee |
| **Traçabilité minimale** | Logging de base | Logs horodatés |
| **Infrastructure** | Déploiement socle technique | Infrastructure prête |

### 1.2 Détail des Étapes Phase 1

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PHASE 1 - DÉTAIL DES ÉTAPES                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  MOIS 1-2: INFRASTRUCTURE                                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 1-2:                                                       │   │
│  │    ✓ Audit infrastructure existante                                │   │
│  │    ✓ Définition topology réseau                                     │   │
│  │    ✓ Plan d'adressage IP sécurisé                                   │   │
│  │                                                                     │   │
│  │  Semaine 3-4:                                                       │   │
│  │    ✓ Déploiement VLANs segmentés                                   │   │
│  │    ✓ Configuration pare-feux                                      │   │
│  │    ✓ Mise en place load balancers                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 2-3: IDENTITY PROVIDER                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 5-6:                                                       │   │
│  │    ✓ Installation Keycloak / Azure AD B2C                          │   │
│  │    ✓ Configuration SAML/OIDC                                       │   │
│  │    ✓ Intégration annuaire national                                 │   │
│  │                                                                     │   │
│  │  Semaine 7-8:                                                       │   │
│  │    ✓ Déploiement certificats hardware (YubiKey)                   │   │
│  │    ✓ Configuration FIDO2                                           │   │
│  │    ✓ Tests authentification multi-facteurs                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 3-4: API GATEWAY                                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 9-10:                                                      │   │
│  │    ✓ Installation Kong / Apigee                                    │   │
│  │    ✓ Configuration mTLS inbound                                   │   │
│  │    ✓ Mise en place WAF                                             │   │
│  │                                                                     │   │
│  │  Semaine 11-12:                                                    │   │
│  │    ✓ Configuration rate limiting                                   │   │
│  │    ✓ Déploiement certificats                                       │   │
│  │    ✓ Tests charge et performance                                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 4-5: LOGGING BASE                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 13-16:                                                     │   │
│  │    ✓ Installation ELK / Splunk lighter                             │   │
│  │    ✓ Configuration logs applicatifs                                │   │
│  │    ✓ Logs authentification                                          │   │
│  │    ✓ Logs requêtes                                                  │   │
│  │    ✓ Configuration rotation                                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 5-6: TESTS ET VALIDATION                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 17-20:                                                     │   │
│  │    ✓ Tests d'intrusion                                              │   │
│  │    ✓ Tests de performance                                          │   │
│  │    ✓ Validation utilisateurs pilotes                               │   │
│  │    ✓ Documentation opérationnelle                                  │   │
│  │                                                                     │   │
│  │  Semaine 21-24:                                                     │   │
│  │    ✓ Mise en production progressif (canary)                        │   │
│  │    ✓ Formation équipes                                             │   │
│  │    ✓ Hypercare                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.3 Budget Phase 1 (Estimation)

| Poste | Coût Estimé (k€) |
|-------|------------------|
| Infrastructure (cloud/on-premise) | 800-1200 |
| Identity Provider | 200-400 |
| API Gateway | 300-500 |
| Hardware tokens | 150-300 |
| Intégration | 400-600 |
| Tests et validation | 200-300 |
| **Total Phase 1** | **2050-3300** |

### 1.4 KPI Phase 1

| Indicateur | Cible | Mesure |
|------------|-------|--------|
| Disponibilité IdP | 99.9% | Uptime monitoring |
| Temps authentification | < 3s | APM |
| Couverture logging | 100% requêtes | Log index |
| Taux MFA | 100% utilisateurs | Audit IdP |

---

## Phase 2: Renforcement Sécurité (Mois 7-12)

### 2.1 Objectifs Phase 2

| Objectif | Description | Livrable |
|----------|-------------|----------|
| **Micro-segmentation** | Isolation données par périmètre | Vaults dédiés |
| **Contrôle déterministe** | Moteur de règles | CRUE |
| **PAM complet** | Accès just-in-time | Bastion |
| **Monitoring avancé** | Détection menaces | SIEM |

### 2.2 Détail des Étapes Phase 2

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PHASE 2 - DÉTAIL DES ÉTAPES                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  MOIS 7-8: MICRO-SEGMENTATION                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 25-28:                                                     │   │
│  │    ✓ Conception modèle de données segmenté                         │   │
│  │    ✓ Déploiement HashiCorp Vault                                   │   │
│  │    ✓ Configuration politiques d'accès                             │   │
│  │    ✓ Migration données (si nécessaire)                             │   │
│  │    ✓ Tests isolation                                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 8-9: MOTEUR DE RÈGLES (CRUE)                                         │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 29-32:                                                     │   │
│  │    ✓ Installation Drools / OpenL Tablets                           │   │
│  │    ✓ Définition règles déterministes                               │   │
│  │    ✓ Intégration API Gateway                                       │   │
│  │    ✓ Versionnage et signatures                                     │   │
│  │    ✓ Tests unitaires règles                                        │   │
│  │                                                                     │   │
│  │  Semaine 33-36:                                                     │   │
│  │    ✓ Règle volume (50/h)                                           │   │
│  │    ✓ Règle justification obligatoire                               │   │
│  │    ✓ Règle interdiction export                                     │   │
│  │    ✓ Règle mission active                                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 9-10: PAM ET BASTION                                                 │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 37-40:                                                     │   │
│  │    ✓ Installation CyberArk / BeyondTrust                           │   │
│  │    ✓ Configuration accès JIT                                       │   │
│  │    ✓ Déploiement bastion jump-host                                │   │
│  │    ✓ Enregistrement sessions                                       │   │
│  │    ✓ Double validation extraction                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 10-11: SIEM ET MONITORING                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 41-44:                                                     │   │
│  │    ✓ Installation Splunk Enterprise / QRadar                      │   │
│  │    ✓ Configuration correlation rules                               │   │
│  │    ✓ Intégration logs toutes sources                                │   │
│  │    ✓ Dashboards sécurité                                           │   │
│  │    ✓ Configuration alertes                                        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 11-12: TESTS ET VALIDATION                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 45-48:                                                     │   │
│  │    ✓ Red team exercise                                             │   │
│  │    ✓ Tests de pénétration                                          │   │
│  │    ✓ Simulation incidents                                          │   │
│  │    ✓ Validation complétude                                         │   │
│  │    ✓ Certification                                                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.3 Budget Phase 2 (Estimation)

| Poste | Coût Estimé (k€) |
|-------|------------------|
| Vault (HashiCorp) | 300-500 |
| Moteur règles (Drools) | 150-250 |
| PAM (CyberArk/BT) | 400-600 |
| SIEM (Splunk/QRadar) | 500-800 |
| Intégration | 300-400 |
| Tests et certifications | 250-400 |
| **Total Phase 2** | **1900-2950** |

### 2.4 KPI Phase 2

| Indicateur | Cible | Mesure |
|------------|-------|--------|
| Isolation vaults | 100% | Audit technique |
| Règles CRUE appliquées | 100% | Log analysis |
| Sessions PAM | 100% privileged | Audit PAM |
| Couverture SIEM | 100% logs | SIEM dashboard |

---

## Phase 3: Perfection et Auto-Défense (Mois 13-18)

### 3.1 Objectifs Phase 3

| Objectif | Description | Livrable |
|----------|-------------|----------|
| **Détection IA** | Analyse comportementale | ML models |
| **Réponse auto** | Automatisation réponse | SOAR |
| **Preuve crypto** | hash quotidien publié | Merkle + blockchain |
| **Attestation externe** | Audit vérifiable | Service attestation |

### 3.2 Détail des Étapes Phase 3

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PHASE 3 - DÉTAIL DES ÉTAPES                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  MOIS 13-14: DÉTECTION IA                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 49-52:                                                     │   │
│  │    ✓ Collecte données historiques (phase 1-2)                     │   │
│  │    ✓ Entraînement modèles ML                                       │   │
│  │      - LSTM détection séquence                                     │   │
│  │      - Autoencoder détection novel patterns                        │   │
│  │      - Clustering utilisateurs                                      │   │
│  │    ✓ Validation modèles                                            │   │
│  │    ✓ Déploiement inference engine                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 14-15: RÉPONSE AUTOMATISÉE                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 53-56:                                                     │   │
│  │    ✓ Installation Splunk SOAR / XSOAR                              │   │
│  │    ✓ Définition playbooks                                          │   │
│  │      - Playbook volume anormal                                      │   │
│  │      - Playbook extraction suspecte                                 │   │
│  │      - Playbook compromission confirmée                            │   │
│  │    ✓ Intégration CRUE et IAM                                       │   │
│  │    ✓ Tests automatisés                                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 15-16: PREUVE CRYPTOGRAPHIQUE                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 57-60:                                                     │   │
│  │    ✓ Implémentation Merkle Tree                                    │   │
│  │    ✓ Génération racine quotidienne                                  │   │
│  │    ✓ Publication blockchain consortium                              │   │
│  │    ✓ Publication Journal Officiel                                  │   │
│  │    ✓ Service vérification intégrité                                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 16-17: ATTESTATION EXTERNE                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 61-64:                                                     │   │
│  │    ✓ Conception service attestation                                │   │
│  │    ✓ Implémentation API vérification                               │   │
│  │    ✓ Intégration auditeurs externes                                │   │
│  │    ✓ Mode "audit externe sécurisé"                                │   │
│  │    ✓ Documentation juridique                                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MOIS 17-18: OPTIMISATION ET PRODUCTION COMPLETE                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Semaine 65-72:                                                     │   │
│  │    ✓ Optimisation performance                                      │   │
│  │    ✓ Tuning détection IA                                           │   │
│  │    ✓ Tests de charge extrêmes                                      │   │
│  │    ✓ Runbooks opérationnels                                       │   │
│  │    ✓ Formation avancée                                             │   │
│  │    ✓ Mise en production 100%                                       │   │
│  │    ✓ Décommissionnement legacy (si applicable)                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.3 Budget Phase 3 (Estimation)

| Poste | Coût Estimé (k€) |
|-------|------------------|
| ML Platform | 300-500 |
| SOAR | 400-600 |
| Infrastructure blockchain | 200-300 |
| Attestation service | 100-150 |
| Optimisation | 150-250 |
| **Total Phase 3** | **1150-1800** |

### 3.4 KPI Phase 3

| Indicateur | Cible | Mesure |
|------------|-------|--------|
| Détection IA | > 95% recall | Red team |
| Temps réponse auto | < 30s | SOAR metrics |
| Publication racine | 100% jours | Vérification |
| Attestation validée | 100% audits | Rapports |

---

## Récapitulatif Global

### Budget Total

| Phase | Durée | Budget (k€) |
|-------|-------|-------------|
| Phase 1: Fondations | 6 mois | 2050-3300 |
| Phase 2: Renforcement | 6 mois | 1900-2950 |
| Phase 3: Auto-Défense | 6 mois | 1150-1800 |
| **TOTAL** | **18 mois** | **5100-8050** |

### Jalons Clés

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    CALENDRIER GLOBAL                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  M1    M2    M3    M4    M5    M6    M7    M8    M9   M10   M11   M12   │
│  │     │     │     │     │     │     │     │     │     │     │     │     │
│  ├─────┴─────┴─────┴─────┴─────┤                                       │  PHASE 1
│  │         FONDATIONS          │                                       │
│  │  ┌─────┐ ┌─────┐ ┌─────┐   │                                       │
│  │  │IdP  │ │Gateway│ │Logs │   │                                       │
│  │  └─────┘ └─────┘ └─────┘   │                                       │
│  │                            ├─────┴─────┴─────┴─────┴─────┤           │  PHASE 2
│  │                            │      RENFORCEMENT           │           │
│  │                            │  ┌─────┐ ┌─────┐ ┌─────┐   │           │
│  │                            │  │Vault│ │CRUE │ │ PAM │   │           │
│  │                            │  └─────┘ └─────┘ └─────┘   │           │
│  │                            │                            ├───────────│  PHASE 3
│  │                            │                            │AUTODÉFENSE │
│  │                            │                            │┌─────┐┌───┐│
│  │                            │                            ││ IA  ││SOAR││
│  │                            │                            │└─────┘└───┘│
│  │                            │                            │            │
│  └────────────────────────────┴────────────────────────────┴────────────┘
│                                                                             │
│  JALONS:                                                                    │
│  ───────                                                                    │
│  M6:  Go-Live Phase 1 (MVP sécurisé)                                       │
│  M12: Go-Live Phase 2 (Micro-segmentation + CRUE)                         │
│  M18: Go-Live Phase 3 (Auto-défense complète)                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Bénéfices Attendus

| Métrique | Avant | Après | Amélioration |
|----------|-------|-------|--------------|
| Surface d'attaque | 100% (accès global) | 15% (segmenté) | -85% |
| Temps détection anomalie | > 24h | < 5 min | -99% |
| Traçabilité | Partielle | 100% (hash + Merkle) | +100% |
| Conformité RGPD | Partielle | 100% (Data minimization) | +100% |
| Réponse incident | Manuel (h) | Automatisé (s) | -99% |

---

## Recommandations

### Priorités Critiques

1. **Phase 1 obligatoire** avant toute mise en production
2. **Authentification FIDO2** comme prérequis absolue
3. **Logging immuable** dès Phase 1 (fondamental pour la preuve juridique)

### Risques et Mitigations

| Risque | Probabilité | Impact | Mitigation |
|--------|-------------|--------|------------|
| Retard livraison | Moyenne | Élevé | Buffer 2 mois planning |
| Budget dépassement | Moyenne | Moyen | Phase gate approvals |
| Résistance utilisateurs | Haute | Moyen | Formation intensive |
| Complexité intégration | Haute | Élevé | POC obligatoires |

### Gouvernance

| Action | Fréquence | Responsable |
|--------|------------|-------------|
| Steering Committee | Mensuel | DSI + Métier |
| Comité sécurité | Bimensuel | RSSI |
| Test intrusion | Trimestriel | Équipe éthique |
| Audit externe | Annuel | Cabinet qualifié |

---

*Document de planification déploiement - Version 1.0*
*Date: 2026-02-23*
