# 🔐 Spécification: Zero-Trust Identity Layer

## 1. Vue d'Ensemble

Cette spécification détaille l'implémentation de la couche d'identité Zero-Trust pour le Registre National des Comptes Bancaires. L'objectif est de garantir que **zéro accès n'est accordé sur la seule base d'un login/mot de passe**.

---

## 2. Principes Fondamentaux

### 2.1 Règles d'Or

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PRINCIPES ZERO-TRUST IDENTITÉ                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  RÈGLE #1: JAMAIS SEULELEMENT CREDENTIALS                                 │
│  ═══════════════════════════════════════════════════════════════════════    │
│                                                                             │
│     ┌─────────────┐         ┌─────────────┐         ┌─────────────┐       │
│     │   Login     │    +    │   Password  │    +    │     MFA     │       │
│     │   (requis)  │         │   (requis)  │         │  (OBLIGAT.) │       │
│     └─────────────┘         └─────────────┘         └─────────────┘       │
│           ✓                      ✓                      ✓                  │
│           │                      │                      │                  │
│           └──────────────────────┼──────────────────────┘                  │
│                                  ▼                                           │
│                          ┌─────────────┐                                    │
│                          │  ACCÈS      │                                    │
│                          │  AUTORISÉ   │                                    │
│                          └─────────────┘                                    │
│                                                                             │
│  RÈGLE #2: DEVICE BINDING OBLIGATOIRE                                     │
│  ═══════════════════════════════════════════════════════════════════════    │
│                                                                             │
│     Utilisateur ──▶ Appareil enregistré ──▶ Certificat binds                │
│                          │                                                   │
│                          ▼                                                   │
│                 ┌─────────────────┐                                         │
│                 │ Attestation     │                                         │
│                 │ FIDO2 validée  │                                         │
│                 └─────────────────┘                                         │
│                                                                             │
│  RÈGLE #3: CONTEXTE DYNAMIQUE                                             │
│  ═══════════════════════════════════════════════════════════════════════    │
│                                                                             │
│     Accès = f(IP, Géoloc, Horaire, Device, Comportement)                  │
│                                                                             │
│  RÈGLE #4: MISSION ACTIVE                                                  │
│  ═══════════════════════════════════════════════════════════════════════    │
│                                                                             │
│     Tout accès doit être validé contre une mission active                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Flux d'Authentification Détaillé

### 3.1 Séquence d'Authentification

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SEQUENCE AUTHENTIFICATION COMPLETE                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ACTOR          IDP                  CRUE              API GATEWAY       │
│  ─────          ───                  ───              ────────────        │
│                                                                             │
│  ┌──────┐                                                                      │
│  │User  │                                                                       │
│  │Agent │                                                                       │
│  └──┬───┘                                                                       │
│     │ 1. Login + Password                                                     │
│     ├───────────────────────────────────▶                                    │
│     │                                    ┌────────────────────────────────┐  │
│     │                                    │ Validation credentials       │  │
│     │                                    │ - Login existe                │  │
│     │                                    │ - Password OK                │  │
│     │                                    │ - Compte actif               │  │
│     │                                    └────────────────┬───────────────┘  │
│     │                                                     │                  │
│     │                                    ┌──────────────┴───────────────┐  │
│     │                                    │ Challenge MFA                │  │
│     │◀──────────────────────────────────│ FIDO2/WebAuthn              │  │
│     │                                    └─────────────────────────────┘  │
│     │                                                                          │
│     │ 2. Authentification FIDO2                                               │
│     │    - Touch / PIN YubiKey                                                │
│     ├──────────────────────────────────▶                                    │
│     │                                    ┌────────────────────────────────┐  │
│     │                                    │ Vérification Device           │  │
│     │                                    │ - Attestation certificate     │  │
│     │                                    │ - Device fingerprint          │  │
│     │                                    │ - Non révoqué                │  │
│     │                                    └────────────────┬───────────────┘  │
│     │                                                     │                  │
│     │                                    ┌──────────────┴───────────────┐  │
│     │                                    │ Vérification contexte         │  │
│     │◀──────────────────────────────────│ - IP whitelist/blacklist    │  │
│     │                                    │ - Géolocation cohérente      │  │
│     │                                    │ - Horaire mission            │  │
│     │                                    └────────────────┬───────────────┘  │
│     │                                                     │                  │
│     │                                    ┌──────────────┴───────────────┐  │
│     │                                    │ Vérification mission active   │  │
│     │                                    │ - Mission ID valide           │  │
│     │                                    │ - Périmètre OK               │  │
│     │                                    │ - Pas expirée                │  │
│     │                                    └────────────────┬───────────────┘  │
│     │                                                     │                  │
│     │                                                     ▼                  │
│     │ 3. TOKEN JWT                                                          │
│     │◀────────────────────────────────── (Si toutes validations OK)        │
│     │  {                                                                       │
│     │    "sub": "AGENT_4571",                                              │
│     │    "org": "GENDARMERIE_NATIONALE",                                   │
│     │    "mission": "MIS_2026_0234",                                       │
│     │    "scope": ["REGION_75", "REGION_92"],                              │
│     │    "iat": 1736687400,                                                │
│     │    "exp": 1736691000,                                                │
│     │    "amr": ["pwd", "fido2", "hwk"]                                    │
│     │  }                                                                     │
│     │                                                                          │
│     │ 4. Requête API + JWT                                                  │
│     ├──────────────────────────────────────────────▶                        │
│     │                                                      │                 │
│     │                                                      ▼                 │
│     │                                    ┌────────────────────────────────┐  │
│     │                                    │ Validation JWT                 │  │
│     │                                    │ - Signature                   │  │
│     │                                    │ - Expiration                  │  │
│     │                                    │ - Claims                      │  │
│     │                                    └────────────────┬───────────────┘  │
│     │                                                     │                  │
│     │                                    ┌──────────────┴───────────────┐  │
│     │                                    │ CRUE - Vérification règles   │  │
│     │                                    │ - Volume/Horre                │  │
│     │                                    │ - Périmètre                  │  │
│     │                                    └────────────────┬───────────────┘  │
│     │                                                     │                  │
│     │                                    ┌──────────────┴───────────────┐  │
│     │                                    │ Décision: ACCEPTER/BLOCK      │  │
│     │◀────────────────────────────────── (Response)                      │
│     │                                                                          │
│     │                                                                          │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Algorithme de Décision

```python
def authenticate(username, password, mfa_response, device_info, request_context):
    
    # ÉTAPE 1: Validation credentials
    user = validate_credentials(username, password)
    if not user:
        log_failure("INVALID_CREDENTIALS", username)
        return Decision.REJECT, "Identifiants invalides"
    
    # ÉTAPE 2: Vérification MFA
    mfa_valid = verify_mfa(user, mfa_response)
    if not mfa_valid:
        log_failure("MFA_FAILED", username)
        notify_security_team(username, "Échec MFA")
        return Decision.REJECT, "Authentification multi-facteurs requise"
    
    # ÉTAPE 3: Vérification device binding
    device_valid = verify_device_binding(user, device_info)
    if not device_valid:
        log_failure("DEVICE_NOT_BINDED", username)
        quarantine_user(username)
        return Decision.REJECT, "Appareil non enregistré"
    
    # ÉTAPE 4: Validation contexte
    context_valid = validate_context(user, request_context)
    if not context_valid:
        log_warning("CONTEXT_ANOMALY", username, request_context)
        # Niveau de risque élevé - requires revalidation
        require_additional_verification(username)
    
    # ÉTAPE 5: Vérification mission active
    mission_valid = verify_active_mission(user, request_context.mission_id)
    if not mission_valid:
        log_failure("NO_ACTIVE_MISSION", username)
        return Decision.REJECT, "Aucune mission active"
    
    # TOUTES LES VALIDATIONS OK
    token = generate_jwt(user, request_context.mission_id)
    log_success("AUTH_SUCCESS", username)
    
    return Decision.ACCEPT, token
```

---

## 4. Configuration FIDO2

### 4.1 Enregistrement Appareil

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ENREGISTREMENT DISPOSITIF FIDO2                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  1. DEMANDE D'ENREGISTREMENT                                                │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Client (Navigateur)          Serveur (Keycloak)                    │   │
│  │        │                              │                              │   │
│  │        │─── POST /fido2/register ───▶│                              │   │
│  │        │                              │                              │   │
│  │        │◀── Challenge (Base64) ──────│                              │   │
│  │        │                              │                              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  2. CRÉATION CREDENTIAL                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Client (YubiKey)                                                    │   │
│  │        │                                                             │   │
│  │        │ Utilisateur présente YubiKey + PIN                        │   │
│  │        │                                                             │   │
│  │        │ Génère:                                                    │   │
│  │        │ - credentialId (identifiant unique)                       │   │
│  │        │ - credentialPublicKey (clé publique)                       │   │
│  │        │ - attestationObject (certificat + signature)             │   │
│  │        │                                                             │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  3. VALIDATION SERVER                                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Serveur:                                                             │   │
│  │   - Vérifier attestation (certificat manufacturier)                │   │
│  │   - Valider signature                                               │   │
│  │   - Stocker: credentialId + credentialPublicKey + device_info     │   │
│  │   - Générer device_fingerprint (SHA-256)                          │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  4. STOCKAGE SÉCURISÉ                                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Table: device_bindings                                               │   │
│  │ ┌────────────────────────────────────────────────────────────────┐  │   │
│  │ │ Column           │ Type          │ Description               │  │   │
│  │ ├──────────────────┼───────────────┼───────────────────────────┤  │   │
│  │ │ user_id          │ UUID          │ Référence utilisateur     │  │   │
│  │ │ credential_id    │ BYTEA         │ Identifiant credential    │  │   │
│  │ │ public_key       │ BYTEA         │ Clé publique (stockée)   │  │   │
│  │ │ device_fp       │ VARCHAR(64)   │ Fingerprint device        │  │   │
│  │ │ attestation_cert │ VARCHAR       │ Certificat attestation    │  │   │
│  │ │ created_at      │ TIMESTAMP     │ Date création             │  │   │
│  │ │ revoked_at      │ TIMESTAMP     │ Date révocation (NULL)   │  │   │
│  │ └──────────────────┴───────────────┴───────────────────────────┘  │   │
│  │                                                                      │   │
│  │ Chiffrement: AES-256-GCM à repos                                   │   │
│  │ Accès: restreint (PAM)                                              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Configuration Keycloak

```yaml
# keycloak-fido2-config.yaml
realm:
  name: rnbc-secure
  
fido2:
  settings:
    # Force attestation pour tous les devices
    attestation: required
    
    # Accept only FIDO2 certified authenticators
    acceptedOrigins:
      - "https://rnbc.fiscalite.gouv.fr"
      - "https://rnbc.justice.gouv.fr"
      
    # User verification required (PIN/Biometrics)
    userVerification: required
    
    # Resident key (允许多设备)
    residentKey: preferred
    
  policy:
    # Maximum devices per user
    maxDevicesPerUser: 3
    
    # Require unique attestation
    uniqueAttestation: true
    
    # Reject unknown attestation formats
    acceptUntrustedAttestations: false
```

---

## 5. Validation Contextuelle

### 5.1 Règles de Validation

| Paramètre | Règle | Action si Échec |
|-----------|-------|-----------------|
| **Adresse IP** | Doit être dans whitelist OU anomalie score < seuil | Challenge additionnel |
| **Géolocation** | Doit correspondre à zone de mission | Blocage + Alerte |
| **Horaire** | Doit être dans plage horaire mission | Blocage |
| **Device** | Doit être lié + non révoqué | Blocage + Quarantaine |
| **Score anomalie** | Doit être < 70/100 | Revalidation MFA |

### 5.2 Détection d'Anomalie Contextuelle

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    VALIDATION CONTEXTUELLE - DÉTAIL                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  SCORE DE RISQUE: 0 (faible) ─────────── 100 (critique)                    │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  IP ADDRESS                                                         │   │
│  │  ┌─────────────────────────────────────────────────────────────┐  │   │
│  │  │ +0   IP dans whitelist organisation                          │  │   │
│  │  │ +10  IP dans range connu (bureau)                           │  │   │
│  │  │ +30  IP VPN organisation (acceptable)                        │  │   │
│  │  │ +50  IP changement récent (dernière semaine)                │  │   │
│  │  │ +70  IP pays différent de l'utilisateur                      │  │   │
│  │  │ +90  IP dans blacklist (proxy/TOR)                           │  │   │
│  │  └─────────────────────────────────────────────────────────────┘  │   │
│  │                                                                      │   │
│  │  GEOLOCATION                                                        │   │
│  │  ┌─────────────────────────────────────────────────────────────┐  │   │
│  │  │ +0   Même ville que d'habitude                               │  │   │
│  │  │ +20  Même région que d'habitude                              │  │   │
│  │  │ +40  Même pays que d'habitude                                │  │   │
│  │  │ +60  Changement ville (voyage?)                              │  │   │
│  │  │ +80  Changement pays (hors EU)                               │  │   │
│  │  │ +90  Pays à risque                                            │  │   │
│  │  └─────────────────────────────────────────────────────────────┘  │   │
│  │                                                                      │   │
│  │  TEMPORALITÉ                                                        │   │
│  │  ┌─────────────────────────────────────────────────────────────┐  │   │
│  │  │ +0   Dans horaires mission                                   │  │   │
│  │  │ +20  Extension horaire (< 2h)                               │  │   │
│  │  │ +50  Hors horaires mission                                   │  │   │
│  │  │ +70  Week-end / holidays                                     │  │   │
│  │  │ +90  Heure inhabituelle (3am-5am)                            │  │   │
│  │  └─────────────────────────────────────────────────────────────┘  │   │
│  │                                                                      │   │
│  │  DÉCISION                                                            │   │
│  │  ┌─────────────────────────────────────────────────────────────┐  │   │
│  │  │ Score 0-30:    ACCÈS DIRECT                                 │  │   │
│  │  │ Score 31-60:   ACCÈS + ALERTE SUPERVISEUR                   │  │   │
│  │  │ Score 61-80:   ACCÈS + REVALIDATION MFA                    │  │   │
│  │  │ Score 81-100:  REFUS + ALERTE SOC                           │  │   │
│  │  └─────────────────────────────────────────────────────────────┘  │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Validation Mission Active

### 6.1 Workflow de Mission

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    VALIDATION MISSION ACTIVE                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    FLUX CRÉATION MISSION                             │   │
│  │                                                                      │   │
│  │  ┌──────────┐      ┌──────────┐      ┌──────────┐                   │   │
│  │  │ Demandeur │ ───▶ │ Validateur│ ───▶ │  Système │                   │   │
│  │  │ (Agent)   │      │ Hiérarchie │      │   (BDD)  │                   │   │
│  │  └──────────┘      └──────────┘      └──────────┘                   │   │
│  │       │                 │                 │                          │   │
│  │       │ Soumission      │ Validation      │                          │   │
│  │       ├──────────────▶   ├─────────────▶   │                          │   │
│  │       │                   │                 │                          │   │
│  │       │                   │ ◀───────────────┤                          │   │
│  │       │                   │                 │                          │   │
│  │       │◀──────────────────┤                                         │   │
│  │       │ Notification      │                                         │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ATTRIBUTS MISSION                                                          │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  {                                                                     │   │
│  │    "mission_id": "MIS_2026_0234",                                  │   │
│  │    "type": "ENQUETE_JUDICIAIRE",                                    │   │
│  │    "organisme": "GENDARMERIE_NATIONALE",                            │   │
│  │    "agent_responsable": "AGENT_4571",                               │   │
│  │    "date_debut": "2026-02-01T00:00:00Z",                            │   │
│  │    "date_fin": "2026-02-28T23:59:59Z",                              │   │
│  │    "statut": "ACTIVE",                                               │   │
│  │    "perimetre": {                                                    │   │
│  │      "type": "GEOGRAPHICAL",                                        │   │
│  │      "regions": ["REGION_75", "REGION_92"],                        │   │
│  │      "departements": [75, 92, 93]                                   │   │
│  │    },                                                                │   │
│  │    "justification": "Enquête disparition inquiétante - dossier X",   │   │
│  │    "reference_judiciaire": "PJ-2026-0234",                          │   │
│  │    "autorisation": {                                                │   │
│  │      "type": "JUGEMENT",                                            │   │   │
│  │      "reference": "TGI Paris 2026-01-15",                          │   │
│  │      "date": "2026-01-15"                                           │   │
│  │    }                                                                 │   │
│  │  }                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  VÉRIFICATION À CHAQUE REQUÊTE                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  SI NOT EXISTS (                                                     │   │
│  │    SELECT 1 FROM missions                                          │   │
│  │    WHERE id = :mission_id                                          │   │
│  │    AND agent_id = :agent_id                                         │   │
│  │    AND statut = 'ACTIVE'                                           │   │
│  │    AND now() BETWEEN date_debut AND date_fin                      │   │
│  │  )                                                                   │   │
│  │  ALORS: REJETER - "Mission inactive ou expirée"                    │   │
│  │                                                                      │   │
│  │  SI compte.region NOT IN mission.perimetre.regions                  │   │
│  │  ALORS: REJETER - "Hors périmètre mission"                         │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 7. Structure JWT

### 7.1 Claims du Token

```json
{
  "header": {
    "alg": "RS256",
    "typ": "JWT",
    "kid": "rnbc-sig-key-2026-v1",
    "x5c": ["MIICXTCCAUUCAQ..."]
  },
  "payload": {
    "iss": "https://idp.rnbc.gouv.fr",
    "sub": "AGENT_4571",
    "name": "Jean DUPONT",
    "org": "GENDARMERIE_NATIONALE",
    "org_code": "GND_075",
    "mission_id": "MIS_2026_0234",
    "mission_type": "ENQUETE_JUDICIAIRE",
    "scope": ["REGION_75", "REGION_92"],
    "perimeter_type": "DEPARTMENTAL",
    "permissions": [
      "account:read:name",
      "account:read:iban",
      "account:read:nir"
    ],
    "not_permissions": [
      "account:export",
      "account:bulk"
    ],
    "iat": 1736687400,
    "exp": 1736691000,
    "jti": "uuid-v4-token-id",
    "amr": ["pwd", "fido2", "hwk"],
    "auth_time": 1736687380,
    "device_fp": "sha256:a1b2c3d4e5f6..."
  },
  "signature": "RSA-SHA256(...)
}
```

---

## 8. Gestion des Sessions

### 8.1 Politique de Session

| Paramètre | Valeur | Justification |
|-----------|--------|----------------|
| **Durée max** | 1 heure | Limiter fenêtre d'attaque |
| **Renewal** | Auto avec revalidation | Continuité sans faille |
| **Absence** | Timeout 15 min | Sécurisé |
| **Single session** | 1 par utilisateur | Empêcher partage |
| **Concurrent alert** | Alerte si double | Détecter partage |

### 8.2 Cycle de Vie

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    CYCLE DE VIE SESSION                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐          │
│  │ CRÉATION│─▶│ ACTIVE  │─▶│ACTIVE  │─▶│EXPIRING │─▶│ EXPIRE  │          │
│  │         │  │         │  │(renewal)│  │         │  │         │          │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘  └─────────┘          │
│       │            │            │            │            │                 │
│       ▼            ▼            ▼            ▼            ▼                 │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐          │
│  │ JWT     │  │ Requête │  │ Revalid│  │Warning  │  │Token    │          │
│  │émis     │  │ acceptée│  │required│  │envoyé   │  │invalidé │          │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘  └─────────┘          │
│                                                                             │
│  TIMERS:                                                                    │
│  - Session timeout: 1h                                                       │
│  - Renewal window: 5min avant expiry                                        │
│  - Absolute max: 8h (avec renewal)                                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 9. Liste de Contrôle Implémentation

### 9.1 Checklist Déploiement

```
□ Composant                  Statut      Date
─────────────────────────────────────────────────────
□ Keycloak cluster           [ ]         _________
□ Configuration FIDO2         [ ]         _________
□ Intégration annuaire       [ ]         _________
□ YubiKey deployment         [ ]         _________
□ Device binding workflow    [ ]         _________
□ Context validation         [ ]         _________
□ Mission management         [ ]         _________
□ JWT custom claims          [ ]         _________
□ Session policies           [ ]         _________
□ Integration API Gateway    [ ]         _________
□ Tests intrusion            [ ]         _________
□ Documentation              [ ]         _________
□ Formation utilisateurs     [ ]         _________
□ Go-Live                    [ ]         _________
```

---

*Document Spécification Identity Layer - Version 1.0*
*Date: 2026-02-23*
