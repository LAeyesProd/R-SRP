# 🛡️ Spécification: Privileged Access Management (PAM)

## 1. Vue d'Ensemble

Ce document spécifie le système de gestion des accès privilégiés (PAM) qui implémente le modèle "Just-in-Time" (JIT) pour minimiser l'exposition des privilèges et garantir une traçabilité complète des sessions privilégiées.

---

## 2. Principes Fondamentaux

### 2.1 Architecture Zero-Privilege

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PRINCIPES PAM - ZERO PRIVILEGE                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  1. PRINCIPE DU MOINS DE PRIVILÈGE                                 │   │
│  │     ────────────────────────────────                                │   │
│  │                                                                     │   │
│  │     Un utilisateur n'a QUE les droits NÉCESSAIRES à sa mission   │   │
│  │     et UNIQUEMENT pour la DURÉE de cette mission.                │   │
│  │                                                                     │   │
│  │       AVANT:              APRÈS:                                    │   │
│  │       ┌─────────┐        ┌─────────────┐                           │   │
│  │       │ Accès   │        │ JIT Access   │                           │   │
│  │       │ permanent│  ────▶│             │                           │   │
│  │       │ à tout  │        │ Request →   │                           │   │
│  │       │         │        │ Approve →   │                           │   │
│  │       └─────────┘        │ Use → Revoke│                           │   │
│  │                          └─────────────┘                           │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  2. JUST-IN-TIME (JIT)                                             │   │
│  │     ─────────────────────                                           │   │
│  │                                                                     │   │
│  │     ┌─────────────┐      ┌─────────────┐      ┌─────────────┐     │   │
│  │     │  DEMANDE    │ ───▶ │ APPROBATION │ ───▶ │  ACCÈS      │     │   │
│  │     │  (Need)     │      │  (Review)   │      │  (Grant)    │     │   │
│  │     └─────────────┘      └─────────────┘      └──────┬──────┘     │   │
│  │                                                          │            │   │
│  │                                                          ▼            │   │
│  │                                                   ┌─────────────┐     │   │
│  │                                                   │  UTILISATION│     │   │
│  │                                                   │  (Time-boxed)│     │   │
│  │                                                   └──────┬──────┘     │   │
│  │                                                          │            │   │
│  │                                                          ▼            │   │
│  │                                                   ┌─────────────┐     │   │
│  │                                                   │  REVOCATION │     │   │
│  │                                                   │  AUTOMATIQUE│     │   │
│  │                                                   └─────────────┘     │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  3. SESSION ISOLÉE                                                  │   │
│  │     ─────────────────                                               │   │
│  │                                                                     │   │
│  │     ┌─────────────────────────────────────────────────────────┐   │   │
│  │     │                    BASTION HOST                         │   │   │
│  │     │                                                          │   │   │
│  │     │  ┌───────────┐  ┌───────────┐  ┌───────────┐          │   │   │
│  │     │  │ Session   │  │ Session   │  │ Session   │          │   │   │
│  │     │  │ Agent A   │  │ Agent B   │  │ Agent C   │          │   │   │
│  │     │  │ (Vault)   │  │ (Vault)   │  │ (Vault)   │          │   │   │
│  │     │  │           │  │           │  │           │          │   │   │
│  │     │  │  Isolated │  │  Isolated │  │  Isolated │          │   │   │
│  │     │  │  Network  │  │  Network  │  │  Network  │          │   │   │
│  │     │  └───────────┘  └───────────┘  └───────────┘          │   │   │
│  │     │                                                          │   │   │
│  │     │  Recording: Video + Keystrokes + Commands             │   │   │
│  │     └─────────────────────────────────────────────────────────┘   │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Workflow Just-in-Time

### 3.1 Cycle de Vie JIT

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    CYCLE DE VIE JIT                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  1. DEMANDE D'ACCÈS                                                │   │
│  │  ─────────────────────────────────────────────────────────────────  │   │
│  │                                                                       │   │
│  │  L'agent demande un accès pour une mission spécifique:             │   │
│  │                                                                       │   │
│  │  POST /api/pam/access/request                                        │   │
│  │  {                                                                   │   │
│  │    "mission_id": "MIS_2026_0234",                                 │   │
│  │    "access_type": "QUERY_REGISTRY",                                 │   │
│  │    "duration": "4h",                                                │   │
│  │    "justification": "Enquête judiciaire dossier X"                 │   │
│  │  }                                                                   │   │
│  │                                                                       │   │
│  │  Vérifications automatiques:                                         │   │
│  │  ✓ Mission active                                                    │   │
│  │  ✓ Agent autorisé sur mission                                        │   │
│  │  ✓ Type d'accès conforme                                            │   │
│  │                                                                       │   │
│  └─────────────────────────────┬───────────────────────────────────────────┘   │
│                                │                                            │
│                                ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  2. APPROBATION                                                     │   │
│  │  ─────────────────────────────────────────────────────────────────  │   │
│  │                                                                       │   │
│  │  Deux modes d'approbation:                                           │   │
│  │                                                                       │   │
│  │  A) Automatique (pour requêtes standards)                           │   │
│  │     └── Si agent评级 > Seuil ET accès standard                      │   │
│  │     └── Timeout: < 30 secondes                                       │   │
│  │                                                                       │   │
│  │  B) Manuelle (pour accès elevated)                                  │   │
│  │     └── Notification superviseur                                     │   │
│  │     └── Timeout: 30 minutes                                          │   │
│  │     └── Refus = ticket bloqué                                        │   │
│  │                                                                       │   │
│  │  ┌─────────────────────────────────────────────────────────────┐   │   │
│  │  │  Demande #REQ-2026-0234-001                               │   │   │
│  │  │  ─────────────────────────────────────────────────────────  │   │   │
│  │  │  Agent: Jean DUPONT (AGENT_4571)                          │   │   │
│  │  │  Mission: Enquête judiciaire MIS_2026_0234                │   │   │
│  │  │  Accès: QUERY_REGISTRY - Region 75                        │   │
│  │  │  Durée: 4 heures                                           │   │
│  │  │  Score IA: 0.15 (normal)                                   │   │   │
│  │  │                                                              │   │   │
│  │  │  [APPROUVER]  [REFUSER]  [MESSAGE]                        │   │   │
│  │  └─────────────────────────────────────────────────────────────┘   │   │
│  │                                                                       │   │
│  └─────────────────────────────┬───────────────────────────────────────────┘   │
│                                │                                            │
│                                ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  3. ATTRIBUTION TEMPORAIRE                                         │   │
│  │  ─────────────────────────────────────────────────────────────────  │   │
│  │                                                                       │   │
│  │  Si approuvé:                                                        │   │
│  │                                                                       │   │
│  │  ✓ Génération token JIT (JWT avec claims limités)                   │   │
│  │  ✓ Attribution permissions temporaires (4h max)                    │   │
│  │  ✓ Mise à jour session agent                                       │   │
│  │  ✓ Notification agent                                               │   │
│  │                                                                       │   │
│  │  {                                                                   │   │
│  │    "access_token": "eyJ...",                                       │   │
│  │    "expires_at": "2026-02-23T18:30:00Z",                         │   │
│  │    "permissions": ["query:name", "query:iban"],                   │   │
│  │    "scope": "REGION_75"                                            │   │
│  │  }                                                                   │   │
│  │                                                                       │   │
│  └─────────────────────────────┬───────────────────────────────────────────┘   │
│                                │                                            │
│                                ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  4. UTILISATION                                                     │   │
│  │  ─────────────────────────────────────────────────────────────────  │   │
│  │                                                                       │   │
│  │  ✓ Session isolée via bastion                                       │   │
│  │  ✓ Recording vidéo + clavier                                      │   │
│  │  ✓ Monitoring temps réel                                           │   │
│  │  ✓ Commandes审计                                                   │   │
│  │  ✓ Accès API avec token JIT                                        │   │
│  │                                                                       │   │
│  │  Limites:                                                           │   │
│  │  - Pas d'export de masse                                            │   │
│  │  - Pas d'accès hors périmètre                                      │   │
│  │  - Timeout 30 min si inactivité                                    │   │
│  │                                                                       │   │
│  └─────────────────────────────┬───────────────────────────────────────────┘   │
│                                │                                            │
│                                ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  5. REVOCATION                                                      │   │
│  │  ─────────────────────────────────────────────────────────────────  │   │
│  │                                                                       │   │
│  │  Déclencheurs de révocation:                                        │   │
│  │                                                                       │   │
│  │  - Fin de durée (4h)                                                │   │
│  │  - Fin de mission                                                    │   │
│  │  - Détection anomalie                                               │   │
│  │  - Demande manuelle agent/superviseur                               │   │
│  │  - Fin de journée (cleanup nocturne)                                │   │
│  │                                                                       │   │
│  │  Actions:                                                            │   │
│  │  ✓ Invalidation token                                               │   │
│  │  ✓ Suppression permissions                                          │   │
│  │  ✓ Fermeture session                                                │   │
│  │  ✓ Archivage recording                                              │   │
│  │                                                                       │   │
│  └───────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Bastion et Session Isolation

### 4.1 Architecture Bastion

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ARCHITECTURE BASTION                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       ZONE DÉMATERIALISÉE                           │   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐               │   │
│  │  │ FISCAL │  │JUSTICE │  │ POLICE │  │ AUTRES  │               │   │
│  │  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘               │   │
│  └───────┼────────────┼────────────┼────────────┼───────────────────────┘   │
│          │            │            │            │                            │
│          └────────────┴────────────┴────────────┘                            │
│                               │                                              │
│                               ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      BASTION HOST (Jump Server)                      │   │
│  │                                                                       │   │
│  │  ┌───────────────────────────────────────────────────────────────┐ │   │
│  │  │                                                               │ │   │
│  │  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐            │ │   │
│  │  │  │   Proxy     │ │   Proxy     │ │   Proxy     │            │ │   │
│  │  │  │ Session A   │ │ Session B   │ │ Session C   │            │ │   │
│  │  │  │ (Vault FISC)│ │(Vault JUST) │ │(Vault POL) │            │ │   │
│  │  │  │             │ │             │ │             │            │ │   │
│  │  │  │ - mTLS      │ │ - mTLS      │ │ - mTLS      │            │ │   │
│  │  │  │ - Isolé     │ │ - Isolé     │ │ - Isolé     │            │ │   │
│  │  │  │ - Encrypted │ │ - Encrypted │ │ - Encrypted │            │ │   │
│  │  │  └─────────────┘ └─────────────┘ └─────────────┘            │ │   │
│  │  │                                                               │ │   │
│  │  │  ┌───────────────────────────────────────────────────────┐  │ │   │
│  │  │  │                  Session Recording                      │  │ │   │
│  │  │  │                                                           │  │ │   │
│  │  │  │  ┌─────────┐  ┌─────────┐  ┌─────────┐               │  │ │   │
│  │  │  │  │  Video   │  │Keystroke│  │Commands │               │  │ │   │
│  │  │  │  │ Record   │  │ Logger  │  │ Auditor │               │  │ │   │
│  │  │  │  └─────────┘  └─────────┘  └─────────┘               │  │ │   │
│  │  │  │                                                           │  │ │   │
│  │  │  │  Chiffrement: AES-256-GCM + Stockage WORM              │  │ │   │
│  │  │  └───────────────────────────────────────────────────────┘  │ │   │
│  │  │                                                               │ │   │
│  │  └───────────────────────────────────────────────────────────────┘ │   │
│  │                                                                       │   │
│  │  SPECIFICATIONS TECHNIQUES:                                         │   │
│  │  - OS: Linux (Debian 12) + Hardened                               │   │
│  │  - Accès: Certificat client obligatoire                            │   │
│  │  - Network: VLAN dédié                                             │   │
│  │  - Monitoring: 24/7                                                │   │
│  │                                                                       │   │
│  └────────────────────────────┬──────────────────────────────────────────┘   │
│                               │                                             │
│                               ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         ZONE SÉCURISÉE                              │   │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐                  │   │
│  │  │   Vault     │ │   Vault     │ │   Vault     │                  │   │
│  │  │  FISCALITÉ  │ │   JUSTICE   │ │   POLICE    │                  │   │
│  │  └─────────────┘ └─────────────┘ └─────────────┘                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Enregistrement de Session

| Type d'Enregistrement | Description | Rétention |
|---------------------|-------------|----------|
| **Vidéo屏幕录制** | Écran complet | 1 an |
| **Clavier** | Touches pressées (sans secrets) | 1 an |
| **Commandes** | API calls | 10 ans |
| **Transferts** | Fichiers upload/download | 10 ans |
| **Métadonnées** | Timestamps, IPs, durées | 10 ans |

---

## 5. Double Validation

### 5.1 Workflow Double Validation

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DOUBLE VALIDATION                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  DÉCLENCHEURS:                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  - > 30 requêtes en 1h + > 10 résultats par requête                │   │
│  │  - > 200 requêtes sur 24h                                          │   │
│  │  - Accès données sensibles (NIR, compte clos)                      │   │
│  │  - Export exceptionnelles (sur approbation)                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  FLUX:                                                                      │
│                                                                             │
│  ┌──────────┐      ┌──────────┐      ┌──────────┐                         │
│  │  Agent   │ ───▶ │  Système  │ ───▶ │Superviseur│                        │
│  │          │      │          │      │          │                         │
│  │ Requête  │      │ Vérifie  │      │ Reçoit   │                         │
│  │ avec     │      │ triggers │      │ notif    │                         │
│  │ résultat │      │ double   │      │          │                         │
│  └────┬─────┘      └────┬─────┘      └────┬─────┘                         │
│       │                 │                 │                                │
│       │                 │    ┌────────────┴────────────┐                  │
│       │                 │    │                         │                   │
│       │                 │    ▼                         ▼                   │
│       │                 │ ┌──────────┐           ┌──────────┐               │
│       │                 │ │ APPROUVE │           │  REFUSE  │               │
│       │                 │ └────┬─────┘           └────┬─────┘               │
│       │                 │      │                      │                     │
│       │                 │      │                      │                     │
│       │    ┌────────────┴──────┘                      │                     │
│       │    │                                       │                      │
│       ▼    ▼                                       │                       │
│  ┌──────────────────────────────────────────┐      │                       │
│  │  SI VALIDÉ:                                │      │                       │
│  │  - Session étendue 1h                     │      │                       │
│  │  - Log avec mention "Validé superviseur"  │      │                       │
│  │  - Notification agent                      │      │                       │
│  └──────────────────────────────────────────┘      │                       │
│                                                   │                       │
│       SI REFUSÉ:                                 │                       │
│       - Session terminée immédiatement            │                       │
│       - Alerte SOC                                │                       │
│       - Revueincident                            │                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Configuration des Politiques

### 6.1 Politiques JIT

```yaml
# pam-policies.yaml
policies:
  - name: "query_registry_standard"
    description: "Accès standard interrogation registre"
    access_type: "QUERY_REGISTRY"
    duration:
      default: "1h"
      max: "4h"
    approval:
      type: "automatic"
      conditions:
        - agent_trust_score: "> 0.8"
        - access_type: "standard"
        - result_count_max: "< 50"
    
  - name: "query_registry_extended"
    description: "Accès étendu interrogation registre"
    access_type: "QUERY_REGISTRY"
    duration:
      default: "2h"
      max: "8h"
    approval:
      type: "manual"
      approver_role: "SUPERVISOR"
      timeout: "30m"
    conditions:
      - mission_type: "ENQUETE_JUDICIAIRE"
      - requires_double_validation: true

  - name: "bulk_export"
    description: "Export massif de données"
    access_type: "EXPORT"
    duration:
      default: "30m"
      max: "1h"
    approval:
      type: "manual"
      approver_role: "DIRECTOR"
      timeout: "1h"
    conditions:
      - requires_justification: true
      - max_records: "1000"
      - requires_audit_trail: true
```

### 6.2 Règles de Session

| Paramètre | Valeur | Description |
|-----------|--------|-------------|
| **Session max** | 4 heures | Durée maximale |
| **Idle timeout** | 15 minutes | Inactivité |
| **Max failed auth** | 3 | Verrouillage |
| **Concurrent sessions** | 1 | Empêcher partage |
| **Recording** | Always | Vidéo + commands |
| **Encryption** | TLS 1.3 | Mandatory |

---

## 7. Intégration avec le SIEM

### 7.1 Événements PAM vers SIEM

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    INTÉGRATION SIEM                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ÉVÉNEMENTS ENVOYÉS:                                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Event ID            Description                    Priority       │   │
│  │  ─────────────────────────────────────────────────────────────────  │   │
│  │  PAM_ACCESS_REQUEST  Demande d'accès               INFO            │   │
│  │  PAM_ACCESS_GRANT    Accès accordé                 INFO            │   │
│  │  PAM_ACCESS_DENIED   Accès refusé                  WARNING         │   │
│  │  PAM_SESSION_START   Début session                  INFO            │   │
│  │  PAM_SESSION_END     Fin session                    INFO            │   │
│  │  PAM_SESSION_IDLE    Session inactive               WARNING         │   │
│  │  PAM_DOUBLE_VALID    Demande double validation     MEDIUM          │   │
│  │  PAM_DOUBLE_APPROVED Validation superviseur         INFO            │   │
│  │  PAM_DOUBLE_REJECTED Refus superviseur             HIGH            │   │
│  │  PAM_REVOKE_AUTO     Révocation automatique        INFO            │   │
│  │  PAM_REVOKE_MANUAL   Révocation manuelle           HIGH            │   │
│  │  PAM_ANOMALY_DETECTED Anomalie détectée            CRITICAL        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  CORRÉLATION AVEC SIEM:                                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                       │   │
│  │  ┌────────────────┐      ┌────────────────┐                       │   │
│  │  │   PAM Events   │ ────▶│    Splunk      │                       │   │
│  │  │   (Kafka)      │      │    Enterprise  │                       │   │
│  │  └────────────────┘      └────────┬───────┘                       │   │
│  │                                  │                                 │   │
│  │                                  ▼                                 │   │
│  │                          ┌───────────────┐                        │   │
│  │                          │   Dashboards  │                        │   │
│  │                          │   & Alerts    │                        │   │
│  │                          └───────────────┘                        │   │
│  │                                                                       │   │
│  │  Exemple règle correlation:                                        │   │
│  │  SI PAM_ACCESS_REQUEST + > 3 refus en 1h ALORS → ALERT SOC        │   │
│  │                                                                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Checklist Implémentation

```
□ Composant                  Statut      Date
─────────────────────────────────────────────────────
□ Installation CyberArk     [ ]         _________
□ Configuration vaults     [ ]         _________
□ Politique JIT            [ ]         _________
□ Workflow approbation     [ ]         _________
□ Bastion déployé          [ ]         _________
□ Session recording        [ ]         _________
□ Double validation        [ ]         _________
□ Intégration SIEM         [ ]         _________
□ Tests intrusion          [ ]         _________
□ Documentation            [ ]         _________
□ Formation équipe          [ ]         _________
□ Go-Live                 [ ]         _________
```

---

*Document Spécification PAM - Version 1.0*
*Date: 2026-02-23*
