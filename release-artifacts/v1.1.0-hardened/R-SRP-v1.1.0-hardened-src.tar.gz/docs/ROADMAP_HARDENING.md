# ROADMAP_HARDENING

## 1. Baseline de r�f�rence

Le projet part d'un �tat d�j� durci sur les points critiques du hard audit: hybrid signature r�elle, RBAC temporel fail-closed, Merkle prefix�, zeroization, posture FIPS stricte, mod�le HSM corrig�, JWT EdDSA strict, rate limiting born�, WAL append-only, UUID complets et TLS strict.

Objectif de cette roadmap: transformer cet �tat en trajectoire compl�te de hardening op�rationnel, conformit� et pr�-certification, avec crit�res de sortie v�rifiables et blocage fail-closed de toute release non conforme.

## 2. Principes de pilotage

- Toute exigence de s�curit� est traduite en contr�le v�rifiable.
- Toute absence d'information critique entra�ne un refus explicite.
- Toute d�rogation est trac�e, born�e et approuv�e formellement.
- Toute preuve doit �tre exportable pour audit externe.
- Toute build de release doit �tre reproductible, sign�e et attest�e.

## 3. Roadmap logique

## Bloc A - Supply chain et builds reproductibles

- Objectif s�curit�: emp�cher l'injection de d�pendances malveillantes et garantir l'int�grit� bit-�-bit des artefacts.
- Modifs code/config/infra attendues: verrouillage strict `Cargo.lock`; politique `deny.toml` bloquante (advisories, bans, sources, licenses); suppression des sources non autoris�es; builds d�terministes avec `--locked --frozen`; comparaison d'empreintes multi-environnements; g�n�ration SBOM syst�matique; signatures et attestations de provenance attach�es aux artefacts.
- Tests � ajouter: test CI de d�rive lockfile; test CI de rejet source git non approuv�e; test de reproductibilit� inter-runners; test de v�rification signature/provenance avant promotion; property test sur stabilit� de hash d'artefacts de build.
- Artefacts de preuve: `deny.toml`; logs `cargo deny`/`cargo audit`; rapports de comparaison de hash; bundles SBOM CycloneDX/SPDX; signatures Cosign; attestations provenance (in-toto/SLSA); runbook de gestion des exceptions supply-chain.
- Crit�res de sortie: aucune d�pendance hors registre autoris�; `cargo deny` bloquant vert; `cargo audit` bloquant vert hors exceptions document�es; hash de reproductibilit� identiques sur runners de r�f�rence; SBOM g�n�r� pour chaque artefact rel�ch�; signature et provenance v�rifi�es en pipeline.

## Bloc B - CI/CD s�curis� et policy production-build-only

- Objectif s�curit�: interdire toute release qui n'emploie pas le profil cryptographique production.
- Modifs code/config/infra attendues: workflow d�di� de gate production; build obligatoire avec `--no-default-features --features production`; rejet explicite de `mock-crypto` dans le graphe de features; tests cibl�s en profil production; contr�le branch protection avec checks requis; politique de promotion conditionn�e aux preuves sign�es.
- Tests � ajouter: test CI n�gatif qui force `mock-crypto` et attend un �chec; test d'int�gration release profile sur `rsrp-demo` et `rsrp-pqcrypto`; fuzz cibl� sur les fronti�res de parsing/validation en mode production; test de non-r�gression des compile-time guards.
- Artefacts de preuve: d�finition du workflow gate; logs de jobs bloquants; rapport de graphe de features; preuves de refus des builds non conformes; attestation de promotion d'image/artefact.
- Crit�res de sortie: aucun artefact release produit si le check production �choue; aucune trace `mock-crypto` dans le graphe production; tous les checks requis activ�s en protection de branche; promotion impossible sans signature+provenance valides.

## Bloc C - Key lifecycle op�rationnel (rotation, r�vocation, destruction)

- Objectif s�curit�: contr�ler l'int�gralit� du cycle de vie des cl�s avec tra�abilit� et destruction v�rifiable.
- Modifs code/config/infra attendues: machine d'�tat explicite `Generated -> Active -> Rotating -> Revoked -> Destroyed`; m�tadonn�es de version et owner pour chaque cl�; registre d'inventaire des cl�s; m�canisme de rotation contr�l�e; liste de r�vocation exploitable en runtime; destruction logique et mat�rielle document�e; int�gration HSM/KMS avec s�paration des privil�ges.
- Tests � ajouter: tests unitaires de transitions d'�tat interdites; tests d'int�gration de rotation sans downtime fonctionnel; tests de r�vocation imm�diate et effet runtime; tests m�moire post-destruction (zeroization); property tests d'invariants de cycle de vie.
- Artefacts de preuve: `KEY_LIFECYCLE_POLICY.md`; journal d'�v�nements de cycle de vie; preuves de r�vocation; comptes-rendus de rotation; runbook d'urgence compromission de cl�; traces d'audit sign�es.
- Crit�res de sortie: aucune cl� active sans owner et policy; aucune transition ill�gale possible; r�vocation effective v�rifi�e en tests d'int�gration; destruction valid�e par tests techniques et proc�dure documentaire; audit trail complet exportable.

## Bloc D - Entropy boundary et RNG (posture FIPS)

- Objectif s�curit�: garantir une fronti�re d'entropie explicite et un comportement fail-closed en cas de source RNG non conforme.
- Modifs code/config/infra attendues: d�finition formelle de la boundary d'entropie; auto-tests de d�marrage RNG; health checks continus sur disponibilit�/qualit� des sources; mode FIPS qui refuse tout fallback; instrumentation d'alerte sur d�gradation RNG; strat�gie de boot qui bloque la mise en service si RNG invalide.
- Tests � ajouter: test de d�marrage avec RNG indisponible; test de d�marrage avec config FIPS invalide; test de non-fallback silencieux; tests de chaos engineering sur d�faillance RNG; fuzz des entr�es de configuration RNG.
- Artefacts de preuve: documentation entropy boundary; logs de health checks RNG; matrice de comportements de boot; rapports de tests de d�faillance; preuves de refus explicite en mode FIPS.
- Crit�res de sortie: service non d�marrable si RNG critique est non conforme; aucun chemin de fallback implicite actif; �v�nements RNG critiques auditables; comportement de refus valid� par tests automatis�s.

## Bloc E - Observabilit� contr�l�e (no-leak, redaction, no-debug prod)

- Objectif s�curit�: garantir la d�tection op�rationnelle sans fuite d'information sensible.
- Modifs code/config/infra attendues: classification des donn�es loggables/non-loggables; redaction centralis�e des champs sensibles; format de logs canonique; interdiction de logs debug/trace en production; politique de r�tention et acc�s restreint aux logs; validation automatique des messages sensibles dans CI.
- Tests � ajouter: tests unitaires de redaction; tests d'int�gration v�rifiant l'absence de secrets en logs; tests de non-r�gression sur formats structur�s; fuzz sur cha�nes d'erreur pour d�tecter fuite de secrets; tests de conformit� de niveaux de log en mode production.
- Artefacts de preuve: politique de logging s�curis�; extraits de logs anonymis�s; rapports d'outils de d�tection de secrets; runbook d'investigation sans exfiltration; preuves CI d'interdiction debug prod.
- Crit�res de sortie: z�ro secret d�tect� dans les logs de test; debug/trace interdits et bloqu�s en production; redaction prouv�e sur tous champs sensibles catalogu�s; acc�s aux logs tra�able et restreint.

## Bloc F - Threat model et Security Target align�s au code

- Objectif s�curit�: rendre la posture de s�curit� d�montrable et tra�able de l'exigence au test.
- Modifs code/config/infra attendues: matrice de tra�abilit� `Threat -> Control -> Test -> Evidence`; harmonisation `THREAT_MODEL`, `THREAT_MODEL_STRIDE` et `SECURITY_TARGET`; cartographie des fronti�res de confiance; formalisation des hypoth�ses d'exploitation; couverture explicite du mode "hostile host".
- Tests � ajouter: tests de sc�nario d'attaque align�s STRIDE; tests de r�gression des contr�les associ�s aux menaces critiques; tests de robustesse des hypoth�ses de confiance (absence d�pendance composant non fiable).
- Artefacts de preuve: `THREAT_MODEL.md`; `THREAT_MODEL_STRIDE.md`; `SECURITY_TARGET.md`; `ATTACK_SCENARIOS.md`; matrice de tra�abilit� sign�e; comptes-rendus de revues d'architecture s�curit�.
- Crit�res de sortie: chaque menace critique a un contr�le, un test et une preuve; aucun contr�le critique sans owner; aucun �cart non justifi� entre documentation et impl�mentation; mode hostile host explicitement trait� et test�.

## Bloc G - Dossier pr�-certification (CSPN r�aliste, EUCC Substantial possible)

- Objectif s�curit�: constituer un paquet d'�vidence pr�t pour audit externe et �valuation pr�-certification.
- Modifs code/config/infra attendues: normalisation du bundle de conformit�; index d'�vidences versionn�; proc�dures de collecte d'artefacts CI; gel des exigences de s�curit� release; formalisation des sc�narios d'attaque et des r�sultats de tests correspondants.
- Tests � ajouter: test de compl�tude du bundle documentaire; test CI de pr�sence des artefacts obligatoires; test de v�rification cryptographique des preuves (signatures, checksums, provenance); exercice de relecture ind�pendante du dossier.
- Artefacts de preuve: `CERTIFICATION_BUNDLE.md`; Security Target; threat model; registre des risques; politiques cycle de vie cl�s; politique supply-chain; r�sultats de tests; SBOM; provenance; signatures; runbooks op�rationnels.
- Crit�res de sortie: bundle complet g�n�rable automatiquement; aucune pi�ce obligatoire manquante; toutes preuves cryptographiques v�rifiables; tra�abilit� exigences-controles-tests compl�te; dossier exploitable sans connaissance tacite du contexte �quipe.

## Bloc H - Attacker model "hostile host" (compromission container/VM)

- Objectif s�curit�: maintenir les garanties essentielles m�me en cas d'h�te partiellement compromis.
- Modifs code/config/infra attendues: s�paration stricte secrets/process; limitation des capacit�s runtime; ex�cution rootless; politiques seccomp/apparmor/SELinux; chiffrement en m�moire et au repos selon boundary; remote attestation quand disponible; strat�gie de rotation/r�vocation acc�l�r�e post-compromission; contr�le d'int�grit� des artefacts au d�marrage.
- Tests � ajouter: tests d'int�gration avec privil�ges r�duits; tests de d�marrage avec artefact alt�r�; tests de r�cup�ration apr�s compromission simul�e; tests de refus d'op�rations sensibles sans attestation/contexte valide; fuzz de surfaces d'entr�e expos�es host.
- Artefacts de preuve: mod�le d'attaquant hostile host; durcissement runtime document�; logs de d�tection d'alt�ration; runbook incident compromission h�te; rapport d'exercice de restauration de confiance.
- Crit�res de sortie: secrets non exploitables hors boundary d�fini; artefact alt�r� toujours refus� au boot; compromission h�te d�clenche r�ponse automatis�e et r�vocation; reprise en �tat de confiance d�montr�e par proc�dure test�e.

## 4. Checklist finale release production (fail-closed)

- [ ] Build ex�cut� en mode production uniquement (`--no-default-features --features production`).
- [ ] Aucun backend mock pr�sent dans le graphe de features release.
- [ ] `cargo fmt`, `clippy -D warnings`, tests unitaires et int�gration s�curit� passent.
- [ ] Tests de hardening critiques passent: hybrid signature, RBAC temporel, Merkle prefix�, zeroization, FIPS fail-closed, TLS strict.
- [ ] `cargo deny` passe sur advisories, bans, licenses, sources.
- [ ] `cargo audit` passe selon politique d'exceptions document�es.
- [ ] Build reproductible v�rifi� sur runners de r�f�rence avec hash identiques.
- [ ] SBOM g�n�r� pour tous artefacts rel�ch�s.
- [ ] Artefacts sign�s et signatures v�rifi�es avant publication.
- [ ] Provenance/attestation g�n�r�e et v�rifi�e (in-toto/SLSA compatible).
- [ ] Journal de cycle de vie des cl�s � jour et r�vocations appliqu�es.
- [ ] Contr�les RNG/FIPS valid�s au d�marrage sans fallback silencieux.
- [ ] Politique de logs s�curis�s valid�e, aucune fuite de secrets d�tect�e.
- [ ] Dossier pr�-certification complet et coh�rent avec le code livr�.
- [ ] Contr�les hostile host valid�s, proc�dures de r�ponse incident test�es.
- [ ] Promotion release bloqu�e automatiquement si un item ci-dessus �choue.

## 5. R�gle de refus automatique

Toute build qui ne satisfait pas l'ensemble de la checklist de release production est rejet�e sans d�rogation implicite.
